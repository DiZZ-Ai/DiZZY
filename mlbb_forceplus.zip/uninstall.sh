#!/system/bin/sh
# ✅ MOBILE LEGENDS: BANG BANG PERFORMANCE OPTIMIZATION REVERT SCRIPT ✅

# 1️⃣ GPU Driver and Graphics Rendering Defaults
settings delete global angle_gl_driver_selection_pkgs
settings delete global angle_gl_driver_selection_values
setprop debug.hwui.renderer opengl
setprop debug.renderengine.disable_scheduler false

# 2️⃣ UI and Animation Speed Defaults
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0

# 3️⃣ Background Process Limit & AppOps Defaults
settings put global background_process_limit 16
cmd appops reset com.mobile.legends

# 4️⃣ Thermal & Performance Mode Defaults
device_config delete game_overlay com.mobile.legends

# 5️⃣ Power Saving & CPU/GPU Defaults
settings put global low_power_mode 1
settings delete global battery_saver_constants

# 6️⃣ Max Refresh Rate Defaults
settings delete system peak_refresh_rate
settings delete system min_refresh_rate

# 7️⃣ Touch Sensitivity Defaults
settings put system pointer_speed 0

# 8️⃣ Sync & Time Defaults
settings put global auto_time 1
settings put global auto_time_zone 1

# 9️⃣ Vibration, Haptics, and Tones Defaults
settings put system haptic_feedback_enabled 1
settings put system vibrate_when_ringing 1
settings put system dtmf_tone 1

# 🔟 Screen Timeout Defaults
settings put system screen_off_timeout 60000

# ✅ Final Confirmation
echo "✅ MOBILE LEGENDS GAMING OPTIMIZATION SETTINGS REVERTED TO DEFAULT!"