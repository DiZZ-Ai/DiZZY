#!/system/bin/sh

clear
sleep 0.8
echo ""
echo "═════════════════════════════════════════════════════════════"
echo "   🧠 AI-OPTIMIZED FPS + REFRESH BOOSTER (DiZZPR0 SYSTEM)    "
echo "   🔧 Powered by SmartDetect™ AI + Radiant Core ⚡            "
echo "   🚀 Version: Adaptive Stable [Universal AI-Tuned Engine]   "
echo "═════════════════════════════════════════════════════════════"
sleep 1

echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""

safe_getprop() {
  val=$(getprop "$1" 2>/dev/null)
  if [ -z "$val" ]; then
    echo "N/A"
  else
    echo "$val"
  fi
}

get_gpu_vendor() {
  vendor=$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES' | cut -d':' -f2 | xargs)
  [ -z "$vendor" ] && echo "N/A" || echo "$vendor"
}

get_battery_info() {
  local stat
  stat=$(dumpsys battery 2>/dev/null | grep "$1" | head -1 | cut -d':' -f2 | tr -d ' ')
  [ -z "$stat" ] && echo "N/A" || echo "$stat"
}

convert_batt_temp() {
  local temp_raw=$1
  if [ "$temp_raw" = "N/A" ] || [ -z "$temp_raw" ]; then
    echo "N/A"
  else
    echo $((temp_raw / 10))
  fi
}

echo "CPU             : $(safe_getprop ro.board.platform)"
echo "CPU ABI         : $(safe_getprop ro.product.cpu.abi)"
echo "CPU Cores       : $(nproc 2>/dev/null || echo "N/A")"
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
echo "CPU Max Freq    : ${CPU_MAX_FREQ:-N/A} kHz"
echo "GPU Renderer    : $(safe_getprop ro.hardware)"
echo "GPU Vendor      : $(get_gpu_vendor)"
echo "Android Version : $(safe_getprop ro.build.version.release) (SDK $(safe_getprop ro.build.version.sdk))"
echo "Build ID        : $(safe_getprop ro.build.display.id)"
echo "Build Type      : $(safe_getprop ro.build.type)"
echo "Build Tags      : $(safe_getprop ro.build.tags)"
echo "Manufacturer    : $(safe_getprop ro.product.manufacturer)"
echo "Brand           : $(safe_getprop ro.product.brand)"
echo "Model           : $(safe_getprop ro.product.model)"
echo "Device          : $(safe_getprop ro.product.device)"
echo "Bootloader Ver  : $(safe_getprop ro.bootloader)"
echo "Baseband Ver    : $(safe_getprop gsm.version.baseband)"
echo "Hardware Serial : $(safe_getprop ro.serialno)"
echo "Kernel Version  : $(uname -r 2>/dev/null || echo N/A)"
echo "SELinux Status  : $(getenforce 2>/dev/null || echo N/A)"
echo "Root Access     : $(if [ "$(id -u)" = 0 ]; then echo "Yes"; else echo "No"; fi)"

BATTERY_STATUS=$(get_battery_info status)
BATTERY_LEVEL=$(get_battery_info level)
BATTERY_TEMP_RAW=$(get_battery_info temperature)
BATTERY_TEMP_C=$(convert_batt_temp "$BATTERY_TEMP_RAW")

echo "Battery Status  : $BATTERY_STATUS"
echo "Battery Level   : ${BATTERY_LEVEL}%" 
echo "Battery Temp    : ${BATTERY_TEMP_C}°C"

if [ -r /proc/meminfo ]; then
  TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | head -1 | awk '{print $2}')
  AVAILABLE_RAM_KB=$(grep MemAvailable /proc/meminfo | head -1 | awk '{print $2}')
  TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
  AVAILABLE_RAM_MB=$((AVAILABLE_RAM_KB / 1024))
  echo "Total RAM       : ${TOTAL_RAM_MB} MB"
  echo "Available RAM   : ${AVAILABLE_RAM_MB} MB"
else
  echo "Total RAM       : N/A"
  echo "Available RAM   : N/A"
fi

DATA_STORAGE=$(df /data 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)
EXT_STORAGE=$(df /storage/emulated/0 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)

echo "Internal Storage: ${DATA_STORAGE:-N/A} (total free)"
echo "External Storage: ${EXT_STORAGE:-N/A} (total free)"

if [ -r /proc/uptime ]; then
  UPTIME_SEC=$(cut -d' ' -f1 /proc/uptime | cut -d'.' -f1)
  UPTIME_H=$((UPTIME_SEC / 3600))
  UPTIME_M=$(((UPTIME_SEC % 3600) / 60))
  echo "Uptime          : ${UPTIME_H}h ${UPTIME_M}m"
else
  echo "Uptime          : N/A"
fi
echo "Last Reboot     : N/A"

sleep 3

clear
echo ""
echo "🤖 SmartDetect AI: Scanning device capabilities..."
sleep 0.5

scan_text="📡 Scanning"
for i in {1..3}; do
  echo -ne "\r$scan_text"
  sleep 0.4
  scan_text="$scan_text."
done
scan_anim='⣾ ⣽ ⣻ ⢿ ⡿ ⣟ ⣯ ⣷'
for i in $(seq 1 3); do
  for frame in $scan_anim; do
    echo -ne "\r🔍 Analyzing $frame"
    sleep 0.1
  done
done
echo -ne "\r🧠 AI Intelligence Mapping: [                    ]"
bar="####################"
for i in $(seq 1 20); do
  sleep 0.06
  echo -ne "\r🧠 AI Intelligence Mapping: [${bar:0:$i}"
  echo -ne "$(printf '%*s' $((20 - i)))]"
done

sleep 0.3
echo -e "\n✅ Scan complete!"

echo ""
echo "🎯 Optimizing system based on ${max_fps}Hz using AI rules..."
echo "──────────────────────────────────────────────"

# Detect maximum supported refresh rate using dumpsys display
max_fps=$(dumpsys display | grep -Eo 'modeId.*[0-9]+Hz' | grep -Eo '[0-9]+Hz' | grep -Eo '[0-9]+' | sort -nr | head -1)
if [ -z "$max_fps" ]; then
  max_fps=60
fi

sleep 0.5

# --- Refresh Rate Boost ---
settings put system user_refresh_rate "$max_fps"
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate "$max_fps"
settings put secure refresh_rate_mode "$max_fps"
settings put system display_refresh_rate "$max_fps"
settings put system peak_refresh_rate "$max_fps"
settings put system min_refresh_rate "$max_fps"
settings put system max_refresh_rate "$max_fps"
settings put system display_min_refresh_rate "$max_fps"
settings put system vendor.display.refresh_rate "$max_fps"
settings put system sf.refresh_rate "$max_fps"
settings put system hwui_refresh_rate "$max_fps"
settings put system max_refresh_rate_for_ui "$max_fps"
settings put system max_refresh_rate_for_gaming "$max_fps"
settings put system thermal_limit_refresh_rate "$max_fps"

# --- FPS Lock Tweaks ---
settings put global min_fps "$max_fps"
settings put global max_fps "$max_fps"
settings put system min_frame_rate "$max_fps"
settings put system max_frame_rate "$max_fps"
settings put system fps_limit "$max_fps"
settings put system NV_FPSLIMIT "$max_fps"
settings put system fps.limit.is.now locked

# --- Margin Boost (Smart AI Tuning) ---
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10

# --- Transition Stability (AI Suggestion Mode) ---
settings put system tran_refresh_mode "$max_fps"
settings put system last_tran_refresh_mode_in_refresh_setting "$max_fps"
settings put system tran_need_recovery_refresh_mode "$max_fps"
settings put system tran_low_battery_60hz_refresh_rate.support 0

# --- Game Driver + Stability Patch ---
settings put global game_driver_all_apps 1
settings put global game_driver_blacklist ""
settings put global sf_latch_unsignaled 1
settings put global enable_frame_rate_override_by_backpressure 1
settings put global enable_frame_rate_override_by_scroll 1

echo ""
echo "✅ AI Optimization Complete!"
echo "✨ System is now dynamically boosted for up to ${max_fps}Hz."
echo "🔋 Balanced. 🔥 Smooth. 🎮 Game-Ready."
echo ""
echo "🤖 SmartDetect AI Engine will keep you ahead with intelligent tuning."
echo "═════════════════════════════════════════════════════════════"