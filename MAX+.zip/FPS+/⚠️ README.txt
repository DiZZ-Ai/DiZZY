╭━━━┳━━━┳━━━╮
┃╭━━┫╭━╮┃╭━╮┃
┃╰━━┫╰━╯┃╰━━╮╭╮
┃╭━━┫╭━━┻━━╮┣╯╰╮
┃┃   ┃┃   ┃╰━╯┣╮╭╯
╰╯   ╰╯   ╰━━━╯╰╯
     🔧 Tutorial & Usage Guide 🔧

🚀 How to Use

1. Place the script (e.g., unlock.sh) in the following location:
                   /sdcard/


2. Run the script via terminal app or ADB shell [RADIANT OR BREVENT]:

👉 sh /sdcard/MAX+/FPS+/unlock.sh


3. To remove the optimizations, simply run:

👉 sh /sdcard/MAX+/FPS+/remove.sh

✅ What It Does

Scans your hardware for refresh rate/FPS capability

Applies smart performance tweaks using AI-based logic

Optimizes GPU/CPU, animation timing, and display flags

Ensures smoother gameplay & lower input latency

⚠️ Disclaimer

📌 Advanced Users Only: Requires basic terminal/ADB experience

📉 Possible Risk: Misuse may affect system stability

💾 Backup First: Always create backups before applying

🚫 No Edits: Avoid modifying the script unless you fully understand it

🛡 No Responsibility: Use at your own risk

💡 Tips

Best results on 90Hz/120Hz/144Hz-capable devices

Pair with Game Mode or Game Booster for extra performance

Reboot after applying for full effect

🐉 Built with 🔥 by DiZZPR0

Enjoy elite performance. Game smooth. Stay sharp.
#FPSBOOSTED • #MAXREFRESH • #DiZZPR0Power
