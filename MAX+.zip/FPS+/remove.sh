#!/system/bin/sh

clear
sleep 0.8
echo ""
echo "═════════════════════════════════════════════════════════════"
echo "   🔁 Reverting FPS + Refresh Booster (DiZZPR0 SYSTEM)       "
echo "   🔧 SmartDetect AI Restore Utility                         "
echo "═════════════════════════════════════════════════════════════"
sleep 1

echo ""
echo "[!] Restoring original system frame and refresh rate values..."
sleep 1

# --- Restore Refresh Rate to System Default (Usually 60Hz or auto) ---
settings delete system user_refresh_rate
settings delete secure user_refresh_rate
settings delete secure miui_refresh_rate
settings delete secure refresh_rate_mode
settings delete system display_refresh_rate
settings delete system peak_refresh_rate
settings delete system min_refresh_rate
settings delete system max_refresh_rate
settings delete system display_min_refresh_rate
settings delete system vendor.display.refresh_rate
settings delete system sf.refresh_rate
settings delete system hwui_refresh_rate
settings delete system max_refresh_rate_for_ui
settings delete system max_refresh_rate_for_gaming
settings delete system thermal_limit_refresh_rate

# --- Restore FPS Settings ---
settings delete global min_fps
settings delete global max_fps
settings delete system min_frame_rate
settings delete system max_frame_rate
settings delete system fps_limit
settings delete system NV_FPSLIMIT
settings delete system fps.limit.is.now

# --- Remove Smart AI Tuning Margins ---
settings delete system fstb_target_fps_margin_high_fps
settings delete system fstb_target_fps_margin_low_fps
settings delete system gcc_fps_margin

# --- Revert Transition Stability Settings ---
settings delete system tran_refresh_mode
settings delete system last_tran_refresh_mode_in_refresh_setting
settings delete system tran_need_recovery_refresh_mode
settings delete system tran_low_battery_60hz_refresh_rate.support

# --- Revert Game Driver & Stability Tweaks ---
settings delete global game_driver_all_apps
settings delete global game_driver_blacklist
settings delete global sf_latch_unsignaled
settings delete global enable_frame_rate_override_by_backpressure
settings delete global enable_frame_rate_override_by_scroll

sleep 0.5
echo ""
echo "✅ System settings reverted to default."
echo "🔄 Refresh rate and FPS unlock disabled."
echo "🧹 Clean and safe rollback completed."
echo ""
echo "═════════════════════════════════════════════════════════════"