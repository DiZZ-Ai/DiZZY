#!/system/bin/sh

sleep 1
echo ""
cat << "EOF"
╔═══╦╗──╔╦═══╦═══╦╗──╔═══╦═══╦╗╔═╗
║╔═╗║╚╗╔╝║╔══╣╔═╗║║──║╔═╗║╔═╗║║║╔╝
║║─║╠╗║║╔╣╚══╣╚═╝║║──║║─║║║─╚╣╚╝╝╔╗
║║─║║║╚╝║║╔══╣╔╗╔╣║─╔╣║─║║║─╔╣╔╗╠╝╚╗
║╚═╝║╚╗╔╝║╚══╣║║╚╣╚═╝║╚═╝║╚═╝║║║╚╗╔╝
╚═══╝─╚╝─╚═══╩╝╚═╩═══╩═══╩═══╩╝╚═╩╝
EOF

sleep 1
echo ""
echo " Developer     : DiZZ PR0 "
echo " Version       : Final "
echo " Tools         : Brevent | Radiant "
echo " Module Type   : Overlock+ Final"
echo ""
echo " ************************************************************************ "
echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""

safe_getprop() {
  val=$(getprop "$1" 2>/dev/null)
  if [ -z "$val" ]; then
    echo "N/A"
  else
    echo "$val"
  fi
}

get_gpu_vendor() {
  vendor=$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES' | cut -d':' -f2 | xargs)
  [ -z "$vendor" ] && echo "N/A" || echo "$vendor"
}

get_battery_info() {
  local stat
  stat=$(dumpsys battery 2>/dev/null | grep "$1" | head -1 | cut -d':' -f2 | tr -d ' ')
  [ -z "$stat" ] && echo "N/A" || echo "$stat"
}

convert_batt_temp() {
  local temp_raw=$1
  if [ "$temp_raw" = "N/A" ] || [ -z "$temp_raw" ]; then
    echo "N/A"
  else
    echo $((temp_raw / 10))
  fi
}

echo "CPU             : $(safe_getprop ro.board.platform)"
echo "CPU ABI         : $(safe_getprop ro.product.cpu.abi)"
echo "CPU Cores       : $(nproc 2>/dev/null || echo "N/A")"
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
echo "CPU Max Freq    : ${CPU_MAX_FREQ:-N/A} kHz"
echo "GPU Renderer    : $(safe_getprop ro.hardware)"
echo "GPU Vendor      : $(get_gpu_vendor)"
echo "Android Version : $(safe_getprop ro.build.version.release) (SDK $(safe_getprop ro.build.version.sdk))"
echo "Build ID        : $(safe_getprop ro.build.display.id)"
echo "Build Type      : $(safe_getprop ro.build.type)"
echo "Build Tags      : $(safe_getprop ro.build.tags)"
echo "Manufacturer    : $(safe_getprop ro.product.manufacturer)"
echo "Brand           : $(safe_getprop ro.product.brand)"
echo "Model           : $(safe_getprop ro.product.model)"
echo "Device          : $(safe_getprop ro.product.device)"
echo "Bootloader Ver  : $(safe_getprop ro.bootloader)"
echo "Baseband Ver    : $(safe_getprop gsm.version.baseband)"
echo "Hardware Serial : $(safe_getprop ro.serialno)"
echo "Kernel Version  : $(uname -r 2>/dev/null || echo N/A)"
echo "SELinux Status  : $(getenforce 2>/dev/null || echo N/A)"
echo "Root Access     : $(if [ "$(id -u)" = 0 ]; then echo "Yes"; else echo "No"; fi)"

BATTERY_STATUS=$(get_battery_info status)
BATTERY_LEVEL=$(get_battery_info level)
BATTERY_TEMP_RAW=$(get_battery_info temperature)
BATTERY_TEMP_C=$(convert_batt_temp "$BATTERY_TEMP_RAW")

echo "Battery Status  : $BATTERY_STATUS"
echo "Battery Level   : ${BATTERY_LEVEL}%" 
echo "Battery Temp    : ${BATTERY_TEMP_C}°C"

if [ -r /proc/meminfo ]; then
  TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | head -1 | awk '{print $2}')
  AVAILABLE_RAM_KB=$(grep MemAvailable /proc/meminfo | head -1 | awk '{print $2}')
  TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
  AVAILABLE_RAM_MB=$((AVAILABLE_RAM_KB / 1024))
  echo "Total RAM       : ${TOTAL_RAM_MB} MB"
  echo "Available RAM   : ${AVAILABLE_RAM_MB} MB"
else
  echo "Total RAM       : N/A"
  echo "Available RAM   : N/A"
fi

DATA_STORAGE=$(df /data 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)
EXT_STORAGE=$(df /storage/emulated/0 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)

echo "Internal Storage: ${DATA_STORAGE:-N/A} (total free)"
echo "External Storage: ${EXT_STORAGE:-N/A} (total free)"

if [ -r /proc/uptime ]; then
  UPTIME_SEC=$(cut -d' ' -f1 /proc/uptime | cut -d'.' -f1)
  UPTIME_H=$((UPTIME_SEC / 3600))
  UPTIME_M=$(((UPTIME_SEC % 3600) / 60))
  echo "Uptime          : ${UPTIME_H}h ${UPTIME_M}m"
else
  echo "Uptime          : N/A"
fi
echo "Last Reboot     : N/A"

sleep 3
echo ""
echo " ************************************************************************ "
echo " - Trimming up Partitions "
sleep 3
echo " - Deleting Cache and Trash "
sleep 5
echo " - Finalizing Props "
sleep 2
echo " - Module Flashed Successfully "
sleep 1
echo ""
echo " - DiZZ PR0 "
echo ""

(
  settings put global window_animation_scale 0.25
  settings put global transition_animation_scale 0.25
  settings put global animator_duration_scale 0.25
  settings put secure display_density_forced 520
  settings put system tap_duration 20
  settings put system view.scroll_friction 3
  settings put secure pointer_speed 10

  input gamepad swipe 200 500 600 500 30
  input touchpad swipe 200 500 300 500 70
  input touchscreen swipe 100 100 500 500 150
  input swipe 500 1000 900 1000 30

  input gamepad tap 250 450
  input touchpad tap 350 650
  input touchscreen tap 130 180
  input tap 750 1150
) > /dev/null 2>&1

(
  settings put system devices_virtual_input_input1_polling_rate 240
  settings put global touch_sampling_rate 240
  settings put global input.sampling_rate 1000
  settings put system persist.sys.touch.sampling_boost 1

  settings put global input.delay 0
  settings put global input.resampling 1
  settings put global input.gesture_prediction 0
  settings put global input.touch_boost 1

  settings put global min.touch.major 0
  settings put global min.touch.minor 0

  settings put system touch.boost true
  settings put system touch.responsive 1
) > /dev/null 2>&1

(
  settings put global touch.pressure.scale 0.1
  settings put global touch.size.scale 0.1

  settings put global settings_enable_monitor_phantom_procs false

  settings put system pointer_speed 5

  settings put global surface_flinger.set_idle_timer_ms 0
  settings put global surface_flinger.set_touch_timer_ms 0
  settings put global surface_flinger.set_display_power_timer_ms 0

  setprop debug.sf.latch_unsignaled 1
  setprop debug.sf.disable_backpressure 1
  setprop debug.sf.multithreaded_present true
  settings put global surface_flinger.use_context_priority 1
) > /dev/null 2>&1

(
  settings put system touch_sampling_rate 120
  settings put system touch_size_calibration geometric
  settings put system touch_stats '{"min":1,"max":1}'
  settings put system touchX_debuggable 1
  settings put system touch_boost_threshold 5
  settings put system touch_feature_gamemode_enable 1
  settings put system touch_input_sensitivity 1
  settings put system touch_rate_control 0
  settings put system touch_response_rate 1
  settings put system touch_sampling_rate_override 1
  settings put system touch_sensitivity 1_2
  settings put system touch_slop 8
  settings put system touch_switch_set_touchscreen 14005
  settings put system touch_tap_sensitivity 1
  settings put system touchpanel_game_switch_enable 1
) > /dev/null 2>&1

(
  settings put global surface_flinger.start_graphics_allocator_service true
  settings put global surface_flinger.running_without_sync_framework true

  setprop debug.sf.luma_sampling 0
  setprop debug.sf.disable_client_composition_cache 1
  setprop debug.sf.disable_backpressure 1

  setprop debug.sf.enable_gl_backpressure 0
  setprop debug.sf.enable_gl_backpressure false
  setprop debug.sf.enable_layer_caching 0

  setprop debug.sf.enable_hwc_vds 0
  setprop debug.sf.hw 0

  setprop debug.sf.predict_hwc_composition_strategy 0

  setprop debug.sf.use_phase_offsets_as_durations 1
) > /dev/null 2>&1

(
  setprop debug.sf.use_phase_offsets_as_durations 1
  setprop debug.sf.late.sf.duration 10500000
  setprop debug.sf.late.app.duration 16600000
  setprop debug.sf.earlyGl.app.duration 16600000

  setprop debug.sf.treat_170m_as_sRGB 1

  setprop debug.sf.frame_rate_multiple_threshold 120
  setprop debug.boot.fps 20

  setprop debug.performance.tuning 1

  settings put global windowsmgr.support_low_latency_touch true

  setprop debug.hwui.render_dirty_regions false
  setprop debug.hwui.disable_vsync true

  settings put system haptic_feedback_intensity 50
  settings put global tactile_feedback_enabled 1

  settings put global touch.onscreen_present true

  settings put global touch_vsync_offset_ns 0
  settings put global touch_phase_offset_ns 0

  settings put global touchpanel_boost 1
  settings put global touch_event_filtering_level 0
  settings put global touch_response_boost_level 3
  settings put global touch_tracking_config optimized

  settings put system multitouch_data_resolution 240
  settings put system multitouch.min_distance 0
  settings put system multitouch_tap_interval 20
  settings put system multitouch_hold_interval 50
  settings put system multitouch_slop 4
  settings put system multitouch_max_events_per_sec 1000

  settings put global tap_interval 10
  settings put global tap_timeout 50
  settings put system long_press_timeout 300
  settings put global double_tap_timeout 200

  settings put system double_tap_to_wake 1
  settings put global quick_tap_enabled 1

  settings put global dev_settings 1
  settings put global development_settings_enabled 1

  settings put system show_touches 0
  settings put system pointer_location 0
  settings put global show_cpu_usage 0
  settings put global show_hw_layers_updates 0
  settings put global show_layout_bounds 0
  settings put system disable_show_touch_visuals 1

  settings put global pointer_speed 7
  settings put secure pointer_speed 7

  settings put global user_rotation 0
  settings put system accelerometer_rotation 0
  settings put system user_rotation 0
  settings put global auto_rotate 0
  settings put system auto_rotate 0

  settings put system screen_off_timeout 300000
  settings put global stay_on_while_plugged_in 3
  settings put global power_saving_mode 0
  settings put global low_power 0
  settings put global display_power_saving 0
  settings put global animation_cache_enabled false
) > /dev/null 2>&1

(
  settings put system user_refresh_rate 144
  settings put system fps_limit 144
  settings put system max_refresh_rate_for_ui 144
  settings put system hwui_refresh_rate 144
  settings put system display_refresh_rate 144
  settings put system max_refresh_rate_for_gaming 144

  settings put system fstb_target_fps_margin_high_fps 20
  settings put system fstb_target_fps_margin_low_fps 20
  settings put system gcc_fps_margin 10

  settings put system tran_low_battery_60hz_refresh_rate.support 0

  settings put system vendor.display.refresh_rate 144
  settings put system sf.refresh_rate 144
  settings put secure miui_refresh_rate 144

  settings put system min_frame_rate 144
  settings put system max_frame_rate 144

  settings put system tran_refresh_mode 144
  settings put system last_tran_refresh_mode_in_refresh_setting 144
  settings put system tran_need_recovery_refresh_mode 144

  settings put global min_fps 144
  settings put global max_fps 144

  settings put system display_min_refresh_rate 144
  settings put system min_refresh_rate 144
  settings put system peak_refresh_rate 144
  settings put secure refresh_rate_mode 144

  settings put system NV_FPSLIMIT 144
  settings put system fps.limit.is.now locked
  settings put system thermal_limit_refresh_rate 144
) > /dev/null 2>&1 &

settings put system sched_migration_cost_ns 500000
settings put system sched_latency_ns 1000000
settings put system sched_min_granularity_ns 200000
settings put system sched_wakeup_granularity_ns 750000
settings put system sched_nr_migrate 2
settings put system perf_cpu_time_max_percent 5
settings put system sched_autogroup_enabled 1
settings put system sched_child_runs_first 1
settings put system sched_cstate_aware 1
settings put system sched_energy_aware 0
settings put system sched_rr_timeslice_ms 10
settings put system sched_rt_period_us 1000000
settings put system sched_rt_runtime_us 950000
settings put system sched_sync_hint_enable 1
settings put system sched_tunable_scaling 1

settings put global game_auto_temperature_control 0
settings put global cached_apps_freezer enabled
setprop debug.restricted_device_performance 0.0
settings put system cpu_boost_dynamic_stune_boost 20
settings put system cpu_boost_dynamic_stune_boost_ms 500
settings put system cpu_boost_input_boost_ms 88
settings put system cpu_boost_powerkey_input_boost_ms 400
settings put system cpu_boost_input_boost_enabled 1
settings put system cpu_boost_sched_boost_on_powerkey_input 1
settings put system cpu_boost_sched_boost_on_input 0

settings put system mali_idler_parameters_mali_idler_active 0
settings put system lazyplug_parameters_nr_possible_cores 8
setprop debug.performance.tuning 1
cmd power set-adaptive-power-saver-enabled false
cmd power set-fixed-performance-mode-enabled true
cmd thermalservice override-status 0

settings put global dropbox:dumpsys:procstats 0
settings put global dropbox:dumpsys:usagestats 0
settings put global surface_flinger.max_frame_buffer_acquired_buffers 3
settings put global surface_flinger.running_without_sync_framework false
setprop debug.cpurend.vsync false
setprop debug.hwui.app_memory_policy aggressive
setprop debug.hwui.optimized_texture_upload true

settings put system kernel_fpsgo_common_fpsgo_enable 1
settings put system cpu_boost_parameters_boost 0
setprop debug.thermal_parameters_enable_throttle 0
setprop debug.thermal_parameters_thermal_enable 0

settings put system peak_refresh_rate 120
settings put system minimum_refresh_rate 120

settings put system sem_enhanced_cpu_responsiveness 1
settings put system sem_performance_mode 4
settings put system sem_turbo_mode 1

settings put system fod_animation_type 4
settings put system force_vulkan_acceleration true
settings put system fps_limit 120
settings put system game_accelerate_hw 1
settings put system game_lag_fix smoothly
settings put system game_access_com_dts_freefireth enable
settings put system game_character_movement 243
settings put system game_no_interruption 0
settings put system gaming_processor_priority true

settings put global cpu.core_speeds.cluster0 2800000
settings put global cpu.core_speeds.cluster1 3200000

settings put system display_use_color_profiles 1
settings put system purgeable_assets 1
settings put system scrollingcache 3
settings put system shutdown_mode hibernate
settings put system sys_ui_hw 1
settings put system sys_use_dithering 1
settings put system config_hw_fast_dormancy 1
settings put system config_hw_quickpoweron true
settings put system config_nocheckin 1
settings put system ril_disable_power_collapse 1
settings put system ril_hsxpa 2

settings put system fw_bg_apps_limit 32
settings put system vendor_qti_sys_fw_b_bg_apps_limit 20
settings put system vendor_qti_wifi_ssr_bw 2
settings put system wifi_supplicant_scan_interval 180

settings put system stune_background_schedtune.boost 0
settings put system stune_background_schedtune.colocate 0
settings put system stune_background_schedtune.prefer_idle 0
settings put system stune_background_schedtune.sched_boost 0
settings put system stune_background_schedtune.sched_boost_no_override 1
settings put system stune_background_schedtune.prefer_perf 0
settings put system stune_background_schedtune.util_est_en 0
settings put system stune_background_schedtune.ontime_en 0

settings put system stune_foreground_schedtune.boost 0
settings put system stune_foreground_schedtune.colocate 0
settings put system stune_foreground_schedtune.prefer_idle 1
settings put system stune_foreground_schedtune.sched_boost 0
settings put system stune_foreground_schedtune.sched_boost_no_override 1
settings put system stune_foreground_schedtune.prefer_perf 0

settings put system cpu_set_effective_cpus 7
settings put system cpu_set_background_cpus 1
settings put system cpu_set_background_effective_cpus 1
settings put system cpu_set_system-background_cpus 2
settings put system cpu_set_system-background_effective_cpus 2
settings put system cpu_set_foreground_cpus 6
settings put system cpu_set_foreground_effective_cpus 6
settings put system cpu_set_top-app_cpus 7
settings put system cpu_set_top-app_effective_cpus 7
settings put system cpu_set_restricted_cpus 3
settings put system cpu_set_restricted_effective_cpus 3

echo "All tweaks applied! Enjoy your maximum level of gaming experience."
