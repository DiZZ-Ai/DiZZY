#!/system/bin/sh

sleep 1
echo ""
cat << "EOF"
╭━━━┳━━━┳╮╱╱╭┳━━━┳━━━┳━━━━╮
┃╭━╮┃╭━━┫╰╮╭╯┃╭━━┫╭━╮┃╭╮╭╮┃
┃╰━╯┃╰━━╋╮┃┃╭┫╰━━┫╰━╯┣╯┃┃╰╯
┃╭╮╭┫╭━━╯┃╰╯┃┃╭━━┫╭╮╭╯╱┃┃
┃┃┃╰┫╰━━╮╰╮╭╯┃╰━━┫┃┃╰╮╱┃┃
╰╯╰━┻━━━╯╱╰╯╱╰━━━┻╯╰━╯╱╰╯
EOF

sleep 1
echo ""
echo " Developer     : DiZZ PR0 "
echo " Version       : Final "
echo " Tools         : Brevent | Radiant "
echo " Module Type   : Overlock+ Final Revert"
echo ""
echo " ************************************************************************ "
echo " CHECKING DEVICE INFORMATION "
sleep 1
echo ""

safe_getprop() {
  val=$(getprop "$1" 2>/dev/null)
  if [ -z "$val" ]; then
    echo "N/A"
  else
    echo "$val"
  fi
}

get_gpu_vendor() {
  vendor=$(dumpsys SurfaceFlinger 2>/dev/null | grep -m1 'GLES' | cut -d':' -f2 | xargs)
  [ -z "$vendor" ] && echo "N/A" || echo "$vendor"
}

get_battery_info() {
  stat=$(dumpsys battery 2>/dev/null | grep "$1" | head -1 | cut -d':' -f2 | tr -d ' ')
  [ -z "$stat" ] && echo "N/A" || echo "$stat"
}

convert_batt_temp() {
  local temp_raw=$1
  if [ "$temp_raw" = "N/A" ] || [ -z "$temp_raw" ]; then
    echo "N/A"
  else
    echo $((temp_raw / 10))
  fi
}

echo "CPU             : $(safe_getprop ro.board.platform)"
echo "CPU ABI         : $(safe_getprop ro.product.cpu.abi)"
echo "CPU Cores       : $(nproc 2>/dev/null || echo "N/A")"
CPU_MAX_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
echo "CPU Max Freq    : ${CPU_MAX_FREQ:-N/A} kHz"
echo "GPU Renderer    : $(safe_getprop ro.hardware)"
echo "GPU Vendor      : $(get_gpu_vendor)"
echo "Android Version : $(safe_getprop ro.build.version.release) (SDK $(safe_getprop ro.build.version.sdk))"
echo "Build ID        : $(safe_getprop ro.build.display.id)"
echo "Build Type      : $(safe_getprop ro.build.type)"
echo "Build Tags      : $(safe_getprop ro.build.tags)"
echo "Manufacturer    : $(safe_getprop ro.product.manufacturer)"
echo "Brand           : $(safe_getprop ro.product.brand)"
echo "Model           : $(safe_getprop ro.product.model)"
echo "Device          : $(safe_getprop ro.product.device)"
echo "Bootloader Ver  : $(safe_getprop ro.bootloader)"
echo "Baseband Ver    : $(safe_getprop gsm.version.baseband)"
echo "Hardware Serial : $(safe_getprop ro.serialno)"
echo "Kernel Version  : $(uname -r 2>/dev/null || echo N/A)"
echo "SELinux Status  : $(getenforce 2>/dev/null || echo N/A)"
echo "Root Access     : $(if [ "$(id -u)" = 0 ]; then echo "Yes"; else echo "No"; fi)"

BATTERY_STATUS=$(get_battery_info status)
BATTERY_LEVEL=$(get_battery_info level)
BATTERY_TEMP_RAW=$(get_battery_info temperature)
BATTERY_TEMP_C=$(convert_batt_temp "$BATTERY_TEMP_RAW")

echo "Battery Status  : $BATTERY_STATUS"
echo "Battery Level   : ${BATTERY_LEVEL}%"
echo "Battery Temp    : ${BATTERY_TEMP_C}°C"

if [ -r /proc/meminfo ]; then
  TOTAL_RAM_KB=$(grep MemTotal /proc/meminfo | head -1 | awk '{print $2}')
  AVAILABLE_RAM_KB=$(grep MemAvailable /proc/meminfo | head -1 | awk '{print $2}')
  TOTAL_RAM_MB=$((TOTAL_RAM_KB / 1024))
  AVAILABLE_RAM_MB=$((AVAILABLE_RAM_KB / 1024))
  echo "Total RAM       : ${TOTAL_RAM_MB} MB"
  echo "Available RAM   : ${AVAILABLE_RAM_MB} MB"
else
  echo "Total RAM       : N/A"
  echo "Available RAM   : N/A"
fi

DATA_STORAGE=$(df /data 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)
EXT_STORAGE=$(df /storage/emulated/0 2>/dev/null | tail -1 | tr -s ' ' | cut -d' ' -f2,4)

echo "Internal Storage: ${DATA_STORAGE:-N/A} (total free)"
echo "External Storage: ${EXT_STORAGE:-N/A} (total free)"

if [ -r /proc/uptime ]; then
  UPTIME_SEC=$(cut -d' ' -f1 /proc/uptime | cut -d'.' -f1)
  UPTIME_H=$((UPTIME_SEC / 3600))
  UPTIME_M=$(((UPTIME_SEC % 3600) / 60))
  echo "Uptime          : ${UPTIME_H}h ${UPTIME_M}m"
else
  echo "Uptime          : N/A"
fi
echo "Last Reboot     : N/A"

sleep 3
echo ""
echo " ************************************************************************ "

echo " - Reverting back to Default"
sleep 3
echo " - Deleting Applied Tweaks"
sleep 5
echo " - Finalizing Removing "
sleep 2
echo " - Revert To Original Successfully "
sleep 1
echo ""
echo " - DiZZ PR0 "
echo ""

settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
settings delete secure display_density_forced
settings delete system tap_duration
settings delete system view.scroll_friction
settings delete secure pointer_speed

settings delete system devices_virtual_input_input1_polling_rate
settings delete global touch_sampling_rate
settings delete global input.sampling_rate
settings delete system persist.sys.touch.sampling_boost

settings delete global input.delay
settings delete global input.resampling
settings delete global input.gesture_prediction
settings delete global input.touch_boost

settings delete global min.touch.major
settings delete global min.touch.minor

settings delete system touch.boost
settings delete system touch.responsive

settings delete global touch.pressure.scale
settings delete global touch.size.scale

settings put global settings_enable_monitor_phantom_procs true

settings delete system pointer_speed

settings delete global surface_flinger.set_idle_timer_ms
settings delete global surface_flinger.set_touch_timer_ms
settings delete global surface_flinger.set_display_power_timer_ms

setprop debug.sf.latch_unsignaled 0
setprop debug.sf.disable_backpressure 0
setprop debug.sf.multithreaded_present 0
settings delete global surface_flinger.use_context_priority

settings delete system touch_sampling_rate
settings delete system touch_size_calibration
settings delete system touch_stats
settings delete system touchX_debuggable
settings delete system touch_boost_threshold
settings delete system touch_feature_gamemode_enable
settings delete system touch_input_sensitivity
settings delete system touch_rate_control
settings delete system touch_response_rate
settings delete system touch_sampling_rate_override
settings delete system touch_sensitivity
settings delete system touch_slop
settings delete system touch_switch_set_touchscreen
settings delete system touch_tap_sensitivity
settings delete system touchpanel_game_switch_enable

settings delete global surface_flinger.start_graphics_allocator_service
settings delete global surface_flinger.running_without_sync_framework

setprop debug.sf.luma_sampling 1
setprop debug.sf.disable_client_composition_cache 0
setprop debug.sf.disable_backpressure 0

setprop debug.sf.enable_gl_backpressure 1
setprop debug.sf.enable_layer_caching 1

setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.hw 1

setprop debug.sf.predict_hwc_composition_strategy 1

setprop debug.sf.use_phase_offsets_as_durations 0

setprop debug.sf.late.sf.duration 0
setprop debug.sf.late.app.duration 0
setprop debug.sf.earlyGl.app.duration 0

setprop debug.sf.treat_170m_as_sRGB 0

setprop debug.sf.frame_rate_multiple_threshold 0
setprop debug.boot.fps 0

setprop debug.performance.tuning 0

settings delete global windowsmgr.support_low_latency_touch

setprop debug.hwui.render_dirty_regions true
setprop debug.hwui.disable_vsync false

settings put system haptic_feedback_intensity 100
settings put global tactile_feedback_enabled 1

settings delete global touch.onscreen_present

settings delete global touch_vsync_offset_ns
settings delete global touch_phase_offset_ns

settings delete global touchpanel_boost
settings delete global touch_event_filtering_level
settings delete global touch_response_boost_level
settings delete global touch_tracking_config

settings delete system multitouch_data_resolution
settings delete system multitouch.min_distance
settings delete system multitouch_tap_interval
settings delete system multitouch_hold_interval
settings delete system multitouch_slop
settings delete system multitouch_max_events_per_sec

settings delete global tap_interval
settings delete global tap_timeout
settings delete system long_press_timeout
settings delete global double_tap_timeout

settings put system double_tap_to_wake 0
settings put global quick_tap_enabled 0

settings put global dev_settings 0
settings put global development_settings_enabled 0

settings put system show_touches 0
settings put system pointer_location 0
settings put global show_cpu_usage 0
settings put global show_hw_layers_updates 0
settings put global show_layout_bounds 0
settings put system disable_show_touch_visuals 0

settings delete global pointer_speed
settings delete secure pointer_speed

settings put global user_rotation 0
settings put system accelerometer_rotation 1
settings put system user_rotation 0
settings put global auto_rotate 1
settings put system auto_rotate 1

settings put system screen_off_timeout 60000
settings put global stay_on_while_plugged_in 0
settings put global power_saving_mode 1
settings put global low_power 1
settings put global display_power_saving 1
settings put global animation_cache_enabled true

settings delete system user_refresh_rate
settings delete system fps_limit
settings delete system max_refresh_rate_for_ui
settings delete system hwui_refresh_rate
settings delete system display_refresh_rate
settings delete system max_refresh_rate_for_gaming

settings delete system fstb_target_fps_margin_high_fps
settings delete system fstb_target_fps_margin_low_fps
settings delete system gcc_fps_margin

settings put system tran_low_battery_60hz_refresh_rate.support 1

settings delete system vendor.display.refresh_rate
settings put system user_refresh_rate 0
settings delete system sf.refresh_rate
settings delete secure miui_refresh_rate

settings delete system min_frame_rate
settings delete system max_frame_rate

settings delete system tran_refresh_mode
settings delete system last_tran_refresh_mode_in_refresh_setting
settings delete system tran_need_recovery_refresh_mode

settings delete global min_fps
settings delete global max_fps

settings delete system display_min_refresh_rate
settings delete system min_refresh_rate
settings delete system peak_refresh_rate
settings delete secure refresh_rate_mode

settings delete system NV_FPSLIMIT
settings delete system fps.limit.is.now
settings delete system thermal_limit_refresh_rate

settings delete system sched_migration_cost_ns
settings delete system sched_latency_ns
settings delete system sched_min_granularity_ns
settings delete system sched_wakeup_granularity_ns
settings delete system sched_nr_migrate
settings delete system perf_cpu_time_max_percent
settings delete system sched_autogroup_enabled
settings delete system sched_child_runs_first
settings delete system sched_cstate_aware
settings delete system sched_energy_aware
settings delete system sched_rr_timeslice_ms
settings delete system sched_rt_period_us
settings delete system sched_rt_runtime_us
settings delete system sched_sync_hint_enable
settings delete system sched_tunable_scaling

settings put global game_auto_temperature_control 1
settings put global cached_apps_freezer disabled
setprop debug.restricted_device_performance 1

settings delete system cpu_boost_dynamic_stune_boost
settings delete system cpu_boost_dynamic_stune_boost_ms
settings delete system cpu_boost_input_boost_ms
settings delete system cpu_boost_powerkey_input_boost_ms
settings delete system cpu_boost_input_boost_enabled
settings delete system cpu_boost_sched_boost_on_powerkey_input
settings delete system cpu_boost_sched_boost_on_input

settings put system mali_idler_parameters_mali_idler_active 1
settings delete system lazyplug_parameters_nr_possible_cores
setprop debug.performance.tuning 0
cmd power set-adaptive-power-saver-enabled true
cmd power set-fixed-performance-mode-enabled false
cmd thermalservice override-status 1

settings delete global dropbox:dumpsys:procstats
settings delete global dropbox:dumpsys:usagestats
settings delete global surface_flinger.max_frame_buffer_acquired_buffers
settings put global surface_flinger.running_without_sync_framework true
setprop debug.cpurend.vsync true
setprop debug.hwui.app_memory_policy default
setprop debug.hwui.optimized_texture_upload false

settings delete system kernel_fpsgo_common_fpsgo_enable
settings delete system cpu_boost_parameters_boost
setprop debug.thermal_parameters_enable_throttle 1
setprop debug.thermal_parameters_thermal_enable 1

settings delete system peak_refresh_rate
settings delete system minimum_refresh_rate

settings delete system sem_enhanced_cpu_responsiveness
settings delete system sem_performance_mode
settings delete system sem_turbo_mode

settings delete system fod_animation_type
settings delete system force_vulkan_acceleration
settings delete system fps_limit
settings delete system game_accelerate_hw
settings delete system game_lag_fix
settings delete system game_access_com_dts_freefireth
settings delete system game_character_movement
settings delete system game_no_interruption
settings delete system gaming_processor_priority

settings delete global cpu.core_speeds.cluster0
settings delete global cpu.core_speeds.cluster1

settings delete system display_use_color_profiles
settings delete system purgeable_assets
settings delete system scrollingcache
settings delete system shutdown_mode
settings delete system sys_ui_hw
settings delete system sys_use_dithering
settings delete system config_hw_fast_dormancy
settings delete system config_hw_quickpoweron
settings delete system config_nocheckin
settings delete system ril_disable_power_collapse
settings delete system ril_hsxpa

settings delete system fw_bg_apps_limit
settings delete system vendor_qti_sys_fw_b_bg_apps_limit
settings delete system vendor_qti_wifi_ssr_bw
settings delete system wifi_supplicant_scan_interval

settings delete system stune_background_schedtune.boost
settings delete system stune_background_schedtune.colocate
settings delete system stune_background_schedtune.prefer_idle
settings delete system stune_background_schedtune.sched_boost
settings delete system stune_background_schedtune.sched_boost_no_override
settings delete system stune_background_schedtune.prefer_perf
settings delete system stune_background_schedtune.util_est_en
settings delete system stune_background_schedtune.ontime_en

settings delete system stune_foreground_schedtune.boost
settings delete system stune_foreground_schedtune.colocate
settings delete system stune_foreground_schedtune.prefer_idle
settings delete system stune_foreground_schedtune.sched_boost
settings delete system stune_foreground_schedtune.sched_boost_no_override
settings delete system stune_foreground_schedtune.prefer_perf

settings delete system cpu_set_effective_cpus
settings delete system cpu_set_background_cpus
settings delete system cpu_set_background_effective_cpus
settings delete system cpu_set_system-background_cpus
settings delete system cpu_set_system-background_effective_cpus
settings delete system cpu_set_foreground_cpus
settings delete system cpu_set_foreground_effective_cpus
settings delete system cpu_set_top-app_cpus
settings delete system cpu_set_top-app_effective_cpus
settings delete system cpu_set_restricted_cpus
settings delete system cpu_set_restricted_effective_cpus

echo "Revert complete! Reboot recommended to fully restore defaults."